#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle belum ditemukan. Pasang Gradle 8.0 dan JDK 17 terlebih dahulu." >&2
  exit 1
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  echo "ANDROID_HOME/ANDROID_SDK_ROOT belum disetel. Arahkan ke folder Android SDK." >&2
  exit 1
fi
gradle assembleDebug
