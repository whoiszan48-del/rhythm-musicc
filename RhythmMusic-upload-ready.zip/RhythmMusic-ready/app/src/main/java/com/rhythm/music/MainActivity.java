package com.rhythm.music;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Rhythm Music - lightweight native Android music discovery and streaming app.
 * Read-only catalog/search and stream endpoints are provided by Audius.
 */
public class MainActivity extends Activity {
    private static final String API = "https://api.audius.co/v1";
    private static final int BG = Color.rgb(9, 11, 16);
    private static final int PANEL = Color.rgb(22, 27, 37);
    private static final int PANEL_2 = Color.rgb(29, 35, 47);
    private static final int TEXT = Color.rgb(244, 246, 252);
    private static final int MUTED = Color.rgb(151, 160, 179);
    private static final int ACCENT = Color.rgb(119, 143, 255);

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(4);
    private final ConcurrentHashMap<String, Bitmap> imageCache = new ConcurrentHashMap<>();
    private final List<Track> searchResults = new ArrayList<>();
    private final List<Track> trendingTracks = new ArrayList<>();
    private final List<Track> favorites = new ArrayList<>();

    private LinearLayout shell;
    private FrameLayout pageHost;
    private LinearLayout miniPlayer;
    private TextView miniTitle;
    private TextView miniArtist;
    private TextView miniPlay;
    private ImageView miniArtwork;

    private int currentPage = 0; // Home, Search, Library, Mood
    private String activeCategory = "All";
    private String searchQuery = "";
    private int searchRequestId = 0;
    private Runnable pendingSearch;
    private LinearLayout searchResultsBox;
    private LinearLayout searchSuggestionsBox;
    private TextView searchStatus;
    private EditText searchInput;
    private LinearLayout categoryTabs;

    private MediaPlayer mediaPlayer;
    private Track currentTrack;
    private List<Track> playbackQueue = new ArrayList<>();
    private int playbackIndex = -1;
    private boolean preparing = false;
    private boolean playing = false;
    private Dialog playerDialog;
    private SeekBar playerSeek;
    private TextView playerTime;
    private TextView playerDuration;
    private TextView playerPlay;
    private ImageView playerArtwork;
    private TextView playerTrackTitle;
    private TextView playerTrackArtist;

    private final Runnable progressTicker = new Runnable() {
        @Override public void run() {
            if (mediaPlayer != null && currentTrack != null && playing) {
                try {
                    int pos = mediaPlayer.getCurrentPosition();
                    int dur = mediaPlayer.getDuration();
                    if (playerSeek != null && !playerSeek.isPressed() && dur > 0) playerSeek.setProgress(pos * 1000 / dur);
                    if (playerTime != null) playerTime.setText(timeText(pos / 1000));
                    if (playerDuration != null && dur > 0) playerDuration.setText(timeText(dur / 1000));
                } catch (Exception ignored) { }
                main.postDelayed(this, 1000);
            }
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        loadFavorites();
        buildShell();
        showHome();
        loadTrending();
    }

    private void buildShell() {
        shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(20), dp(12), dp(18), dp(10));
        TextView brand = text("Rhythm", 24, TEXT, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(38), 1));
        TextView subtitle = text("MUSIC", 10, MUTED, true);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setLetterSpacing(.16f);
        top.addView(subtitle, new LinearLayout.LayoutParams(dp(58), dp(36)));
        TextView profile = text("♪", 22, TEXT, true);
        profile.setGravity(Gravity.CENTER);
        profile.setBackground(bg(PANEL_2, 100));
        top.addView(profile, new LinearLayout.LayoutParams(dp(38), dp(38)));
        shell.addView(top, new LinearLayout.LayoutParams(-1, dp(58)));

        pageHost = new FrameLayout(this);
        shell.addView(pageHost, new LinearLayout.LayoutParams(-1, 0, 1));

        miniPlayer = new LinearLayout(this);
        miniPlayer.setGravity(Gravity.CENTER_VERTICAL);
        miniPlayer.setPadding(dp(12), dp(7), dp(12), dp(7));
        miniPlayer.setBackground(bg(Color.rgb(28, 34, 47), 16));
        miniPlayer.setVisibility(View.GONE);
        miniArtwork = new ImageView(this);
        miniArtwork.setScaleType(ImageView.ScaleType.CENTER_CROP);
        miniPlayer.addView(miniArtwork, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout miniText = vertical();
        miniText.setPadding(dp(10), 0, dp(8), 0);
        miniTitle = text("Belum ada lagu", 13, TEXT, true);
        miniArtist = text("Pilih lagu untuk mulai", 11, MUTED, false);
        miniText.addView(miniTitle);
        miniText.addView(miniArtist);
        miniPlayer.addView(miniText, new LinearLayout.LayoutParams(0, -2, 1));
        miniPlay = text("▶", 20, TEXT, true);
        miniPlay.setGravity(Gravity.CENTER);
        miniPlay.setOnClickListener(v -> togglePlayback());
        miniPlayer.addView(miniPlay, new LinearLayout.LayoutParams(dp(42), dp(44)));
        TextView next = text("▶|", 16, TEXT, true);
        next.setGravity(Gravity.CENTER);
        next.setOnClickListener(v -> playNext());
        miniPlayer.addView(next, new LinearLayout.LayoutParams(dp(42), dp(44)));
        miniPlayer.setOnClickListener(v -> openPlayer());
        LinearLayout.LayoutParams miniParams = new LinearLayout.LayoutParams(-1, dp(60));
        miniParams.setMargins(dp(10), dp(4), dp(10), dp(5));
        shell.addView(miniPlayer, miniParams);

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(4), dp(5), dp(4), dp(7));
        nav.setBackgroundColor(Color.rgb(12, 15, 22));
        String[] labels = {"⌂\nHome", "⌕\nSearch", "▤\nLibrary", "✧\nMood"};
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            TextView item = text(labels[i], 11, MUTED, true);
            item.setGravity(Gravity.CENTER);
            item.setLineSpacing(dp(1), 1f);
            item.setOnClickListener(v -> navigate(index));
            nav.addView(item, new LinearLayout.LayoutParams(0, dp(52), 1));
        }
        shell.addView(nav, new LinearLayout.LayoutParams(-1, dp(60)));
        setContentView(shell);
    }

    private void navigate(int page) {
        currentPage = page;
        if (page == 0) showHome();
        else if (page == 1) showSearch();
        else if (page == 2) showLibrary();
        else showMood();
    }

    private void showHome() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = vertical();
        body.setPadding(dp(18), dp(8), dp(18), dp(22));
        int hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        String greeting = hour < 11 ? "Good morning" : (hour < 18 ? "Good afternoon" : "Good evening");
        body.addView(text(greeting, 25, TEXT, true));
        body.addView(text("Mau mendengarkan apa hari ini?", 13, MUTED, false));
        addSpace(body, 18);

        body.addView(sectionTitle("Mood & suasana", "PILIH SUASANA"));
        LinearLayout moodRow = horizontal();
        String[] moods = {"Chill", "Focus", "Sad", "Commute", "Gaming", "Sleep", "Energy", "Party", "Workout"};
        for (String mood : moods) moodRow.addView(chip(mood, () -> openMoodSearch(mood)), new LinearLayout.LayoutParams(-2, dp(38)));
        body.addView(horizontalScroll(moodRow));
        addSpace(body, 20);

        body.addView(sectionTitle("Speed dial", "PENCARIAN CEPAT"));
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        String[][] picks = {{"Lagu Indonesia", "pop indonesia"}, {"Funkot", "funkot"}, {"Lo-fi", "lofi chill"}, {"Pop", "pop"}};
        for (int r = 0; r < 2; r++) {
            LinearLayout row = horizontal();
            for (int c = 0; c < 2; c++) {
                String[] pick = picks[r * 2 + c];
                TextView tile = text("♫   " + pick[0], 13, TEXT, true);
                tile.setGravity(Gravity.CENTER_VERTICAL);
                tile.setPadding(dp(12), 0, dp(8), 0);
                tile.setBackground(bg(PANEL, 12));
                tile.setOnClickListener(v -> openMoodSearch(pick[1]));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(58), 1);
                lp.setMargins(0, 0, dp(8), dp(8));
                row.addView(tile, lp);
            }
            grid.addView(row);
        }
        body.addView(grid);
        addSpace(body, 12);
        body.addView(sectionTitle("Trending di Audius", "LAGU YANG SEDANG RAMAI"));
        LinearLayout trendBox = vertical();
        body.addView(trendBox);
        if (trendingTracks.isEmpty()) {
            TextView loading = text("Mengambil lagu populer…", 13, MUTED, false);
            loading.setPadding(0, dp(12), 0, dp(12));
            trendBox.addView(loading);
        } else {
            for (Track t : trendingTracks) trendBox.addView(trackRow(t, trendingTracks));
        }
        addSpace(body, 15);
        TextView attribution = text("Katalog musik dan streaming disediakan oleh Audius.", 10, MUTED, false);
        body.addView(attribution);
        scroll.addView(body);
        setPage(scroll);
    }

    private void showSearch() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = vertical();
        body.setPadding(dp(16), dp(6), dp(16), dp(20));
        body.addView(text("Search", 25, TEXT, true));
        body.addView(text("Cari lagu, artis, atau playlist", 12, MUTED, false));
        addSpace(body, 14);

        LinearLayout searchBar = horizontal();
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(dp(12), 0, dp(10), 0);
        searchBar.setBackground(bg(PANEL_2, 24));
        TextView searchIcon = text("⌕", 23, MUTED, false);
        searchBar.addView(searchIcon, new LinearLayout.LayoutParams(dp(28), dp(48)));
        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(14);
        searchInput.setTextColor(TEXT);
        searchInput.setHintTextColor(MUTED);
        searchInput.setHint("Cari judul lagu atau artis…");
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        searchInput.setPadding(0, 0, 0, 0);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBar.addView(searchInput, new LinearLayout.LayoutParams(0, dp(48), 1));
        TextView clear = text("×", 22, MUTED, true);
        clear.setGravity(Gravity.CENTER);
        clear.setOnClickListener(v -> searchInput.setText(""));
        searchBar.addView(clear, new LinearLayout.LayoutParams(dp(28), dp(48)));
        body.addView(searchBar);
        addSpace(body, 12);

        categoryTabs = horizontal();
        categoryTabs.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(horizontalScroll(categoryTabs));
        refreshCategoryTabs();
        addSpace(body, 10);

        searchStatus = text("Mulai ketik untuk mencari lagu…", 12, MUTED, false);
        body.addView(searchStatus);
        searchSuggestionsBox = vertical();
        body.addView(searchSuggestionsBox);
        populateSuggestions();
        searchResultsBox = vertical();
        body.addView(searchResultsBox);
        scroll.addView(body);
        setPage(scroll);

        searchInput.setText(searchQuery);
        searchInput.setSelection(searchInput.length());
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s.toString().trim();
                scheduleSearch(searchQuery);
            }
            @Override public void afterTextChanged(Editable e) { }
        });
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                if (pendingSearch != null) main.removeCallbacks(pendingSearch);
                runSearch(searchQuery);
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
                return true;
            }
            return false;
        });
        if (searchQuery.length() > 1) runSearch(searchQuery);
    }

    private void populateSuggestions() {
        searchSuggestionsBox.removeAllViews();
        TextView label = text("Pencarian populer", 13, TEXT, true);
        label.setPadding(dp(2), dp(4), 0, dp(8));
        searchSuggestionsBox.addView(label);
        String[] suggestions = {"funkot", "pop indonesia", "lofi chill", "dangdut", "acoustic", "electronic"};
        for (String suggestion : suggestions) {
            LinearLayout row = horizontal();
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView ico = text("↗", 15, MUTED, true);
            row.addView(ico, new LinearLayout.LayoutParams(dp(28), dp(42)));
            TextView name = text(suggestion, 13, TEXT, false);
            row.addView(name, new LinearLayout.LayoutParams(0, dp(42), 1));
            TextView arrow = text("⌕", 17, MUTED, false);
            row.addView(arrow, new LinearLayout.LayoutParams(dp(25), dp(42)));
            row.setOnClickListener(v -> {
                searchInput.setText(suggestion);
                searchInput.setSelection(searchInput.length());
            });
            searchSuggestionsBox.addView(row);
            addDivider(searchSuggestionsBox);
        }
    }

    private void refreshCategoryTabs() {
        if (categoryTabs == null) return;
        categoryTabs.removeAllViews();
        String[] cats = {"All", "Songs", "Videos", "Albums", "Artists"};
        for (String c : cats) {
            TextView tab = text(c, 12, c.equals(activeCategory) ? Color.WHITE : MUTED, true);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(dp(14), 0, dp(14), 0);
            tab.setBackground(bg(c.equals(activeCategory) ? Color.rgb(69, 87, 154) : PANEL, 22));
            tab.setOnClickListener(v -> {
                activeCategory = c;
                refreshCategoryTabs();
                if (searchQuery.length() > 1) runSearch(searchQuery);
                else if (searchStatus != null) searchStatus.setText("Ketik kata kunci untuk mencari " + c.toLowerCase(Locale.ROOT) + ".");
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.setMargins(0, 0, dp(7), 0);
            categoryTabs.addView(tab, lp);
        }
    }

    private void scheduleSearch(String query) {
        if (pendingSearch != null) main.removeCallbacks(pendingSearch);
        searchRequestId++;
        if (searchResultsBox != null) searchResultsBox.removeAllViews();
        if (searchSuggestionsBox != null) searchSuggestionsBox.setVisibility(query.length() == 0 ? View.VISIBLE : View.GONE);
        if (query.length() < 2) {
            if (searchStatus != null) searchStatus.setText("Mulai ketik untuk mencari lagu…");
            return;
        }
        if (searchStatus != null) searchStatus.setText("Mencari “" + query + "”…");
        final String q = query;
        pendingSearch = () -> runSearch(q);
        main.postDelayed(pendingSearch, 450);
    }

    private void runSearch(String query) {
        if (query == null || query.trim().length() < 2 || searchResultsBox == null) return;
        final int req = ++searchRequestId;
        final String q = query.trim();
        final String category = activeCategory;
        if (searchSuggestionsBox != null) searchSuggestionsBox.setVisibility(View.GONE);
        if (searchStatus != null) searchStatus.setText("Sedang mencari “" + q + "”…");
        searchResultsBox.removeAllViews();
        io.execute(() -> {
            try {
                JSONObject response;
                if ("Artists".equals(category)) response = apiGet("/users/search?query=" + enc(q) + "&limit=25");
                else if ("Albums".equals(category)) response = apiGet("/playlists/search?query=" + enc(q) + "&limit=25");
                else if ("Videos".equals(category)) response = null;
                else response = apiGet("/tracks/search?query=" + enc(q) + "&limit=30&sort_method=relevant");
                List<Track> found = new ArrayList<>();
                if (response != null) {
                    JSONArray arr = response.optJSONArray("data");
                    if (arr != null) for (int i = 0; i < arr.length(); i++) {
                        JSONObject item = arr.optJSONObject(i);
                        if (item == null) continue;
                        if ("Artists".equals(category)) found.add(parseArtist(item));
                        else if ("Albums".equals(category)) found.add(parseAlbum(item));
                        else found.add(parseTrack(item));
                    }
                }
                main.post(() -> {
                    if (req != searchRequestId || searchResultsBox == null) return;
                    searchResults.clear(); searchResults.addAll(found);
                    if ("Videos".equals(category)) {
                        searchStatus.setText("Katalog Audius saat ini berfokus pada musik audio, bukan video.");
                        return;
                    }
                    if (found.isEmpty()) {
                        searchStatus.setText("Tidak ada hasil untuk “" + q + "”. Coba kata kunci lain.");
                        return;
                    }
                    searchStatus.setText(found.size() + " hasil ditemukan");
                    for (Track track : found) {
                        if ("Artists".equals(category)) searchResultsBox.addView(artistRow(track));
                        else if ("Albums".equals(category)) searchResultsBox.addView(albumRow(track));
                        else searchResultsBox.addView(trackRow(track, found));
                    }
                });
            } catch (Exception e) {
                main.post(() -> {
                    if (req != searchRequestId || searchStatus == null) return;
                    searchStatus.setText("Pencarian gagal. Periksa koneksi internet lalu coba lagi.");
                });
            }
        });
    }

    private void showLibrary() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = vertical();
        body.setPadding(dp(18), dp(8), dp(18), dp(20));
        body.addView(text("Library", 25, TEXT, true));
        body.addView(text("Koleksi musik milikmu", 12, MUTED, false));
        addSpace(body, 16);
        LinearLayout liked = horizontal();
        liked.setGravity(Gravity.CENTER_VERTICAL);
        liked.setPadding(dp(14), dp(12), dp(12), dp(12));
        liked.setBackground(bg(PANEL_2, 16));
        TextView heart = text("♥", 26, ACCENT, true);
        heart.setGravity(Gravity.CENTER);
        liked.addView(heart, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout likedText = vertical();
        likedText.setPadding(dp(10), 0, 0, 0);
        likedText.addView(text("Liked Songs", 15, TEXT, true));
        likedText.addView(text(favorites.size() + " lagu tersimpan", 11, MUTED, false));
        liked.addView(likedText, new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(liked);
        addSpace(body, 18);
        body.addView(sectionTitle("Lagu favorit", "TERSIMPAN DI PERANGKAT"));
        if (favorites.isEmpty()) {
            TextView empty = text("Belum ada lagu favorit. Tekan ikon ♡ pada lagu untuk menyimpannya di sini.", 13, MUTED, false);
            empty.setPadding(dp(3), dp(10), dp(3), dp(10));
            body.addView(empty);
        } else {
            for (Track t : new ArrayList<>(favorites)) body.addView(trackRow(t, favorites));
        }
        addSpace(body, 18);
        TextView info = text("Favorit disimpan secara lokal di HP ini. Streaming membutuhkan koneksi internet.", 11, MUTED, false);
        body.addView(info);
        scroll.addView(body);
        setPage(scroll);
    }

    private void showMood() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = vertical();
        body.setPadding(dp(18), dp(8), dp(18), dp(24));
        body.addView(text("Mood", 25, TEXT, true));
        body.addView(text("Pilih suasana, Rhythm akan mencarikan lagu.", 12, MUTED, false));
        addSpace(body, 18);
        String[][] moods = {
                {"Chill", "lofi chill relaxing"}, {"Fokus", "instrumental focus"},
                {"Sedih", "sad acoustic"}, {"Semangat", "upbeat pop"},
                {"Gaming", "gaming electronic"}, {"Tidur", "ambient sleep"},
                {"Party", "dance party"}, {"Workout", "workout energy"},
                {"Indonesia", "pop indonesia"}
        };
        for (String[] mood : moods) {
            TextView card = text("♫     " + mood[0] + "\n        Cari musik untuk suasana ini", 14, TEXT, true);
            card.setPadding(dp(16), dp(12), dp(12), dp(12));
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setBackground(bg(PANEL, 14));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(65));
            lp.setMargins(0, 0, 0, dp(9));
            body.addView(card, lp);
            card.setOnClickListener(v -> openMoodSearch(mood[1]));
        }
        scroll.addView(body);
        setPage(scroll);
    }

    private void openMoodSearch(String query) {
        searchQuery = query;
        activeCategory = "All";
        navigate(1);
    }

    private void loadTrending() {
        io.execute(() -> {
            try {
                JSONObject response = apiGet("/tracks/trending?time=week&limit=12");
                JSONArray arr = response.optJSONArray("data");
                List<Track> found = new ArrayList<>();
                if (arr != null) for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o != null) found.add(parseTrack(o));
                }
                main.post(() -> {
                    trendingTracks.clear(); trendingTracks.addAll(found);
                    if (currentPage == 0) showHome();
                });
            } catch (Exception ignored) {
                main.post(() -> {
                    if (currentPage == 0 && trendingTracks.isEmpty()) showHome();
                });
            }
        });
    }

    private LinearLayout trackRow(Track track, List<Track> queue) {
        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2), dp(7), dp(2), dp(7));
        ImageView cover = new ImageView(this);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setBackground(bg(PANEL_2, 9));
        loadArtwork(track.artwork, cover, 54);
        row.addView(cover, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout info = vertical();
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(11), 0, dp(4), 0);
        TextView name = text(track.title, 13, TEXT, true);
        name.setMaxLines(1); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView by = text(track.artist + (track.duration > 0 ? "  •  " + timeText(track.duration) : ""), 11, MUTED, false);
        by.setMaxLines(1); by.setEllipsize(android.text.TextUtils.TruncateAt.END);
        info.addView(name); info.addView(by);
        row.addView(info, new LinearLayout.LayoutParams(0, dp(56), 1));
        TextView favorite = text(isFavorite(track) ? "♥" : "♡", 20, isFavorite(track) ? ACCENT : MUTED, true);
        favorite.setGravity(Gravity.CENTER);
        favorite.setOnClickListener(v -> {
            toggleFavorite(track);
            favorite.setText(isFavorite(track) ? "♥" : "♡");
            favorite.setTextColor(isFavorite(track) ? ACCENT : MUTED);
        });
        row.addView(favorite, new LinearLayout.LayoutParams(dp(38), dp(48)));
        TextView more = text("⋮", 21, MUTED, true);
        more.setGravity(Gravity.CENTER);
        more.setOnClickListener(v -> showTrackMenu(track, queue));
        row.addView(more, new LinearLayout.LayoutParams(dp(30), dp(48)));
        row.setOnClickListener(v -> playTrack(track, queue));
        return row;
    }

    private LinearLayout artistRow(Track artist) {
        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(9), 0, dp(9));
        ImageView art = new ImageView(this);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        art.setBackground(bg(PANEL_2, 100));
        loadArtwork(artist.artwork, art, 58);
        row.addView(art, new LinearLayout.LayoutParams(dp(58), dp(58)));
        LinearLayout info = vertical(); info.setPadding(dp(12), 0, 0, 0);
        info.addView(text(artist.title, 14, TEXT, true));
        info.addView(text("Artist di Audius", 11, MUTED, false));
        row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = text("›", 24, MUTED, true); go.setGravity(Gravity.CENTER);
        row.addView(go, new LinearLayout.LayoutParams(dp(35), dp(48)));
        row.setOnClickListener(v -> openMoodSearch(artist.title));
        return row;
    }

    private LinearLayout albumRow(Track album) {
        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(9), 0, dp(9));
        ImageView art = new ImageView(this);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        art.setBackground(bg(PANEL_2, 9));
        loadArtwork(album.artwork, art, 58);
        row.addView(art, new LinearLayout.LayoutParams(dp(58), dp(58)));
        LinearLayout info = vertical(); info.setPadding(dp(12), 0, 0, 0);
        info.addView(text(album.title, 14, TEXT, true));
        info.addView(text(album.artist, 11, MUTED, false));
        row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = text("▶", 16, MUTED, true); go.setGravity(Gravity.CENTER);
        row.addView(go, new LinearLayout.LayoutParams(dp(40), dp(48)));
        row.setOnClickListener(v -> loadAlbumTracks(album));
        return row;
    }

    private void loadAlbumTracks(Track album) {
        if (searchStatus != null) searchStatus.setText("Membuka playlist…");
        io.execute(() -> {
            try {
                JSONObject response = apiGet("/playlists/" + enc(album.id) + "/tracks?limit=50");
                JSONArray arr = response.optJSONArray("data");
                List<Track> tracks = new ArrayList<>();
                if (arr != null) for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i); if (o != null) tracks.add(parseTrack(o));
                }
                main.post(() -> {
                    if (searchResultsBox == null) return;
                    searchResultsBox.removeAllViews();
                    searchStatus.setText(tracks.size() + " lagu dalam " + album.title);
                    for (Track t : tracks) searchResultsBox.addView(trackRow(t, tracks));
                });
            } catch (Exception e) {
                main.post(() -> { if (searchStatus != null) searchStatus.setText("Playlist tidak bisa dibuka saat ini."); });
            }
        });
    }

    private void showTrackMenu(Track track, List<Track> queue) {
        String[] options = {"Putar sekarang", isFavorite(track) ? "Hapus dari favorit" : "Tambahkan ke favorit", "Buka di Audius"};
        new android.app.AlertDialog.Builder(this)
                .setTitle(track.title)
                .setItems(options, (d, which) -> {
                    if (which == 0) playTrack(track, queue);
                    else if (which == 1) { toggleFavorite(track); Toast.makeText(this, isFavorite(track) ? "Ditambahkan ke favorit" : "Dihapus dari favorit", Toast.LENGTH_SHORT).show(); }
                    else if (which == 2 && track.permalink != null && !track.permalink.isEmpty()) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(track.permalink))); } catch (Exception ignored) { }
                    }
                }).show();
    }

    private void playTrack(Track track, List<Track> queue) {
        if (track == null || track.id == null || track.id.isEmpty()) return;
        playbackQueue = new ArrayList<>(queue == null ? new ArrayList<>() : queue);
        playbackIndex = -1;
        for (int i = 0; i < playbackQueue.size(); i++) if (track.id.equals(playbackQueue.get(i).id)) { playbackIndex = i; break; }
        if (playbackIndex < 0) { playbackQueue.add(track); playbackIndex = playbackQueue.size() - 1; }
        startTrack(track);
    }

    private void startTrack(Track track) {
        releasePlayer();
        currentTrack = track;
        preparing = true; playing = false;
        updateMiniPlayer();
        Toast.makeText(this, "Memuat: " + track.title, Toast.LENGTH_SHORT).show();
        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mediaPlayer.setOnPreparedListener(mp -> {
                preparing = false; playing = true;
                mp.start(); updateMiniPlayer();
                main.removeCallbacks(progressTicker); main.post(progressTicker);
            });
            mediaPlayer.setOnCompletionListener(mp -> playNext());
            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                preparing = false; playing = false; updateMiniPlayer();
                Toast.makeText(this, "Lagu tidak dapat diputar. Coba lagu lain.", Toast.LENGTH_LONG).show();
                return true;
            });
            mediaPlayer.setDataSource(API + "/tracks/" + Uri.encode(track.id) + "/stream");
            mediaPlayer.prepareAsync();
        } catch (Exception e) {
            preparing = false; playing = false; updateMiniPlayer();
            Toast.makeText(this, "Gagal memulai pemutar musik.", Toast.LENGTH_SHORT).show();
        }
    }

    private void togglePlayback() {
        if (mediaPlayer == null || currentTrack == null) return;
        try {
            if (preparing) return;
            if (mediaPlayer.isPlaying()) { mediaPlayer.pause(); playing = false; }
            else { mediaPlayer.start(); playing = true; main.post(progressTicker); }
            updateMiniPlayer(); updatePlayerDialogControls();
        } catch (Exception ignored) { }
    }

    private void playNext() {
        if (playbackQueue.isEmpty()) return;
        int next = playbackIndex + 1;
        if (next >= playbackQueue.size()) next = 0;
        playbackIndex = next;
        startTrack(playbackQueue.get(playbackIndex));
    }

    private void playPrevious() {
        if (playbackQueue.isEmpty()) return;
        if (mediaPlayer != null) {
            try { if (mediaPlayer.getCurrentPosition() > 3500) { mediaPlayer.seekTo(0); return; } } catch (Exception ignored) { }
        }
        int prev = playbackIndex - 1;
        if (prev < 0) prev = playbackQueue.size() - 1;
        playbackIndex = prev;
        startTrack(playbackQueue.get(playbackIndex));
    }

    private void releasePlayer() {
        main.removeCallbacks(progressTicker);
        if (mediaPlayer != null) {
            try { mediaPlayer.setOnPreparedListener(null); mediaPlayer.setOnCompletionListener(null); mediaPlayer.stop(); } catch (Exception ignored) { }
            try { mediaPlayer.release(); } catch (Exception ignored) { }
            mediaPlayer = null;
        }
    }

    private void updateMiniPlayer() {
        if (currentTrack == null) { miniPlayer.setVisibility(View.GONE); return; }
        miniPlayer.setVisibility(View.VISIBLE);
        miniTitle.setText(currentTrack.title);
        miniArtist.setText(currentTrack.artist);
        miniPlay.setText(preparing ? "…" : (playing ? "Ⅱ" : "▶"));
        loadArtwork(currentTrack.artwork, miniArtwork, 46);
        updatePlayerDialogControls();
    }

    private void openPlayer() {
        if (currentTrack == null) return;
        Dialog dialog = new Dialog(this);
        playerDialog = dialog;
        LinearLayout root = vertical();
        root.setPadding(dp(22), dp(24), dp(22), dp(20));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackground(bg(Color.rgb(13, 17, 26), 24));
        TextView heading = text("NOW PLAYING", 11, MUTED, true);
        heading.setLetterSpacing(.16f);
        root.addView(heading);
        addSpace(root, 24);
        ImageView art = new ImageView(this);
        playerArtwork = art;
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        art.setBackground(bg(PANEL_2, 18));
        loadArtwork(currentTrack.artwork, art, 260);
        root.addView(art, new LinearLayout.LayoutParams(dp(260), dp(260)));
        addSpace(root, 28);
        TextView title = text(currentTrack.title, 21, TEXT, true);
        playerTrackTitle = title;
        title.setGravity(Gravity.CENTER);
        title.setMaxLines(2);
        root.addView(title);
        TextView artist = text(currentTrack.artist, 14, MUTED, false);
        playerTrackArtist = artist;
        artist.setGravity(Gravity.CENTER);
        root.addView(artist);
        addSpace(root, 24);
        SeekBar seek = new SeekBar(this);
        seek.setMax(1000); seek.setProgress(0);
        root.addView(seek, new LinearLayout.LayoutParams(-1, dp(32)));
        playerSeek = seek;
        LinearLayout times = horizontal();
        playerTime = text("0:00", 11, MUTED, false);
        playerDuration = text(timeText(currentTrack.duration), 11, MUTED, false);
        times.addView(playerTime, new LinearLayout.LayoutParams(0, -2, 1));
        playerDuration.setGravity(Gravity.RIGHT);
        times.addView(playerDuration, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(times);
        addSpace(root, 20);
        LinearLayout controls = horizontal(); controls.setGravity(Gravity.CENTER);
        TextView prev = text("|◀", 25, TEXT, true); prev.setGravity(Gravity.CENTER);
        TextView play = text(preparing ? "…" : (playing ? "Ⅱ" : "▶"), 30, TEXT, true);
        playerPlay = play;
        play.setGravity(Gravity.CENTER); play.setBackground(bg(ACCENT, 100));
        TextView next = text("▶|", 25, TEXT, true); next.setGravity(Gravity.CENTER);
        controls.addView(prev, new LinearLayout.LayoutParams(dp(72), dp(60)));
        LinearLayout.LayoutParams playLp = new LinearLayout.LayoutParams(dp(66), dp(60));
        controls.addView(play, playLp);
        controls.addView(next, new LinearLayout.LayoutParams(dp(72), dp(60)));
        root.addView(controls);
        addSpace(root, 14);
        TextView attribution = text("Music streaming by Audius", 10, MUTED, false);
        root.addView(attribution);
        prev.setOnClickListener(v -> playPrevious());
        next.setOnClickListener(v -> playNext());
        play.setOnClickListener(v -> togglePlayback());
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean user) { }
            @Override public void onStartTrackingTouch(SeekBar b) { }
            @Override public void onStopTrackingTouch(SeekBar b) {
                if (mediaPlayer != null && !preparing) try { mediaPlayer.seekTo(mediaPlayer.getDuration() * b.getProgress() / 1000); } catch (Exception ignored) { }
            }
        });
        dialog.setContentView(root);
        dialog.setOnDismissListener(d -> {
            if (playerDialog == dialog) playerDialog = null;
            playerSeek = null; playerTime = null; playerDuration = null; playerPlay = null;
            playerArtwork = null; playerTrackTitle = null; playerTrackArtist = null;
        });
        Window w = dialog.getWindow();
        if (w != null) { w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout(-1, -1); }
        dialog.show();
        if (dialog.getWindow() != null) dialog.getWindow().setLayout(-1, -1);
        updatePlayerDialogControls();
    }

    private void updatePlayerDialogControls() {
        if (playerDialog == null || !playerDialog.isShowing()) return;
        if (currentTrack != null) {
            if (playerTrackTitle != null) playerTrackTitle.setText(currentTrack.title);
            if (playerTrackArtist != null) playerTrackArtist.setText(currentTrack.artist);
            if (playerArtwork != null) loadArtwork(currentTrack.artwork, playerArtwork, 260);
            if (playerDuration != null) playerDuration.setText(timeText(currentTrack.duration));
        }
        if (playerPlay != null) playerPlay.setText(preparing ? "…" : (playing ? "Ⅱ" : "▶"));
        if (playerSeek != null && mediaPlayer != null && !preparing) {
            try { int dur = mediaPlayer.getDuration(); if (dur > 0 && !playerSeek.isPressed()) playerSeek.setProgress(mediaPlayer.getCurrentPosition() * 1000 / dur); } catch (Exception ignored) { }
        }
    }

    private void toggleFavorite(Track track) {
        if (isFavorite(track)) {
            for (int i = favorites.size() - 1; i >= 0; i--) if (track.id.equals(favorites.get(i).id)) favorites.remove(i);
        } else favorites.add(track);
        saveFavorites();
        if (currentPage == 2) showLibrary();
    }

    private boolean isFavorite(Track track) {
        if (track == null) return false;
        for (Track t : favorites) if (track.id.equals(t.id)) return true;
        return false;
    }

    private void saveFavorites() {
        JSONArray a = new JSONArray();
        for (Track t : favorites) a.put(t.toJson());
        getSharedPreferences("rhythm", MODE_PRIVATE).edit().putString("favorites", a.toString()).apply();
    }

    private void loadFavorites() {
        SharedPreferences p = getSharedPreferences("rhythm", MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("favorites", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i); if (o != null) favorites.add(Track.fromJson(o));
            }
        } catch (Exception ignored) { }
    }

    private JSONObject apiGet(String path) throws Exception {
        URL url = new URL(API + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(14000);
        c.setReadTimeout(18000);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "RhythmMusic/1.0 Android");
        int code = c.getResponseCode();
        InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close(); c.disconnect();
        String raw = out.toString("UTF-8");
        JSONObject obj = new JSONObject(raw);
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + raw);
        return obj;
    }

    private Track parseTrack(JSONObject o) {
        Track t = new Track();
        t.id = o.optString("id", o.optString("track_id", ""));
        t.title = o.optString("title", o.optString("track_name", "Untitled"));
        JSONObject user = o.optJSONObject("user");
        t.artist = user != null ? user.optString("name", user.optString("handle", "Unknown artist")) : o.optString("artist_name", "Unknown artist");
        t.artwork = artworkFrom(o.optJSONObject("artwork"));
        if (t.artwork.isEmpty()) t.artwork = o.optString("cover_art", "");
        t.duration = o.optInt("duration", 0);
        t.permalink = o.optString("permalink", "");
        t.kind = "song";
        return t;
    }

    private Track parseArtist(JSONObject o) {
        Track t = new Track();
        t.id = o.optString("id", "");
        t.title = o.optString("name", o.optString("handle", "Artist"));
        t.artist = "Artist";
        t.artwork = artworkFrom(o.optJSONObject("profile_picture"));
        t.kind = "artist";
        t.permalink = "https://audius.co/" + o.optString("handle", "");
        return t;
    }

    private Track parseAlbum(JSONObject o) {
        Track t = new Track();
        t.id = o.optString("id", "");
        t.title = o.optString("playlist_name", o.optString("title", "Playlist"));
        JSONObject user = o.optJSONObject("user");
        t.artist = user != null ? user.optString("name", "Audius creator") : "Audius playlist";
        t.artwork = artworkFrom(o.optJSONObject("artwork"));
        if (t.artwork.isEmpty()) t.artwork = o.optString("cover_art", "");
        t.kind = "album";
        t.permalink = o.optString("permalink", "");
        return t;
    }

    private String artworkFrom(JSONObject o) {
        if (o == null) return "";
        String[] keys = {"_480x480", "480x480", "_150x150", "150x150", "_1000x1000", "1000x1000"};
        for (String k : keys) { String v = o.optString(k, ""); if (!v.isEmpty() && v.startsWith("http")) return v; }
        return "";
    }

    private void loadArtwork(String url, ImageView target, int sizeDp) {
        target.setImageDrawable(placeholder(sizeDp));
        if (url == null || url.isEmpty()) return;
        Bitmap cached = imageCache.get(url);
        if (cached != null) { target.setImageBitmap(cached); return; }
        io.execute(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(9000); c.setReadTimeout(12000);
                InputStream in = c.getInputStream();
                Bitmap bitmap = BitmapFactory.decodeStream(in);
                in.close(); c.disconnect();
                if (bitmap != null) {
                    imageCache.put(url, bitmap);
                    main.post(() -> { if (target.getTag() == null || url.equals(target.getTag())) target.setImageBitmap(bitmap); });
                }
            } catch (Exception ignored) { }
        });
        target.setTag(url);
    }

    private android.graphics.drawable.Drawable placeholder(int sizeDp) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(43, 54, 88), Color.rgb(24, 31, 45)});
        d.setCornerRadius(dp(9));
        return d;
    }

    private void setPage(View page) {
        pageHost.removeAllViews();
        pageHost.addView(page, new FrameLayout.LayoutParams(-1, -1));
    }

    private LinearLayout sectionTitle(String title, String kicker) {
        LinearLayout row = horizontal();
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(title, 17, TEXT, true);
        row.addView(t, new LinearLayout.LayoutParams(0, dp(30), 1));
        TextView k = text(kicker, 8, MUTED, true);
        k.setLetterSpacing(.10f);
        row.addView(k);
        return row;
    }

    private TextView chip(String label, Runnable action) {
        TextView v = text(label, 11, TEXT, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(14), 0, dp(14), 0);
        v.setBackground(bg(PANEL, 22));
        v.setOnClickListener(w -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(36));
        lp.setMargins(0, 0, dp(7), 0);
        v.setLayoutParams(lp);
        return v;
    }

    private HorizontalScrollView horizontalScroll(View child) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(child);
        return h;
    }

    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private void addSpace(LinearLayout parent, int height) {
        View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private void addDivider(LinearLayout parent) {
        View d = new View(this); d.setBackgroundColor(Color.rgb(35, 41, 53));
        parent.addView(d, new LinearLayout.LayoutParams(-1, dp(1)));
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }
    private String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8"); }
    private String timeText(int seconds) { return String.format(Locale.getDefault(), "%d:%02d", Math.max(0, seconds) / 60, Math.max(0, seconds) % 60); }

    @Override public void onBackPressed() {
        if (playerDialog != null && playerDialog.isShowing()) { playerDialog.dismiss(); playerDialog = null; return; }
        if (currentPage != 0) { navigate(0); return; }
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        releasePlayer();
        io.shutdownNow();
        super.onDestroy();
    }

    private static class Track {
        String id = "";
        String title = "";
        String artist = "";
        String artwork = "";
        String permalink = "";
        String kind = "song";
        int duration = 0;

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id); o.put("title", title); o.put("artist", artist);
                o.put("artwork", artwork); o.put("permalink", permalink);
                o.put("kind", kind); o.put("duration", duration);
            } catch (Exception ignored) { }
            return o;
        }

        static Track fromJson(JSONObject o) {
            Track t = new Track();
            t.id = o.optString("id", ""); t.title = o.optString("title", "");
            t.artist = o.optString("artist", ""); t.artwork = o.optString("artwork", "");
            t.permalink = o.optString("permalink", ""); t.kind = o.optString("kind", "song");
            t.duration = o.optInt("duration", 0);
            return t;
        }
    }
}
