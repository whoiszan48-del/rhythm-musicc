# Rhythm Music — proyek Android siap build APK

Proyek ini disiapkan agar APK dibuat otomatis melalui GitHub Actions.

## Cara dari HP Android

1. Ekstrak ZIP ini.
2. Buat repository baru di https://github.com/new (misalnya `RhythmMusic`).
3. Upload **seluruh isi folder proyek ini** ke repository. Pastikan folder tersembunyi `.github/workflows` ikut ter-upload.
4. Buka tab **Actions** di repository.
5. Pilih workflow **Build APK**. Jika belum berjalan otomatis, tekan **Run workflow**.
6. Tunggu sampai proses berstatus `Success`.
7. Buka hasil workflow, cari bagian **Artifacts**, lalu unduh `RhythmMusic-debug-apk`.
8. Ekstrak artifact ZIP. Di dalamnya ada `app-debug.apk`.
9. Buka APK di HP untuk memasangnya. Android mungkin meminta izin memasang aplikasi dari sumber tersebut.

## Apa yang dilakukan otomatis?

GitHub Actions memasang JDK 17, Android SDK Platform 33, Gradle 8.0, lalu menjalankan:

```bash
gradle --no-daemon assembleDebug
```

APK hasil build diunggah sebagai artifact bernama `RhythmMusic-debug-apk`.

## Build manual

Persyaratan: JDK 17, Gradle 8.0, Android SDK Platform 33 dan Build Tools 33.0.2.

```bash
gradle assembleDebug
```

APK berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur

- Pencarian lagu otomatis berdasarkan judul atau penyanyi.
- Hasil pencarian ditampilkan di dalam aplikasi.
- Streaming dari katalog Audius (ketersediaan lagu mengikuti katalog dan izin kreator).
- Play/Pause, Next, Previous, progress lagu, mini player.
- Favorit tersimpan lokal.

## Catatan

ZIP ini adalah **source project siap diunggah untuk proses build otomatis**, bukan file APK. APK biner baru tersedia setelah workflow GitHub Actions selesai sukses. APK debug cocok untuk instalasi dan pengujian; distribusi publik biasanya memerlukan APK release yang ditandatangani.
